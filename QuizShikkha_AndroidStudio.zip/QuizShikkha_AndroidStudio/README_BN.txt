Quiz শিক্ষা — Android Studio project

এই প্রজেক্টে Google Mobile Ads SDK এবং টেস্ট বিজ্ঞাপন ID যুক্ত আছে।
এটি এখনই আপনার নিজের AdMob অ্যাকাউন্টের আয়ের জন্য প্রস্তুত নয়।

আপনার নিজের বিজ্ঞাপন চালুর আগে:
1. AdMob-এ অ্যাপ রেজিস্টার করুন এবং নিজের App ID সংগ্রহ করুন।
2. app/src/main/AndroidManifest.xml-এ com.google.android.gms.ads.APPLICATION_ID-এর টেস্ট App ID নিজের App ID দিয়ে বদলান।
3. MainActivity.java-তে BANNER_AD_UNIT_ID এবং INTERSTITIAL_AD_UNIT_ID-তে নিজের Ad Unit ID বসান।
4. Android Studio-তে প্রজেক্ট খুলে Gradle Sync করুন এবং Build > Build APK(s) নির্বাচন করুন।
5. প্রথমে টেস্ট বিজ্ঞাপন দিয়ে পরীক্ষা করুন। নিজের বিজ্ঞাপনে নিজে ক্লিক করবেন না; বিজ্ঞাপনে কৃত্রিম ক্লিক/ইমপ্রেশন তৈরি করবেন না।
6. প্রকাশের আগে Google Play/AdMob-এর বর্তমান নীতি, সম্মতি ও গোপনীয়তা সংক্রান্ত প্রয়োজনীয়তা পূরণ করুন।

প্রজেক্টে Unity Ads SDK যোগ করা নেই; এই সংস্করণে Google AdMob-এর ব্যানার ও ইন্টারস্টিশিয়াল টেস্ট বিজ্ঞাপন প্রস্তুত রাখা হয়েছে।
এই প্রজেক্ট তৈরি করা মানেই বিজ্ঞাপন অনুমোদন বা আয় নিশ্চিত নয়।
