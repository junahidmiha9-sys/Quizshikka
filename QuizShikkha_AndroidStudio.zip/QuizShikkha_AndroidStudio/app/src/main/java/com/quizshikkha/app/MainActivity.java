package com.quizshikkha.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;

public class MainActivity extends Activity {
    // Google's official TEST ad unit IDs. Replace with your own AdMob IDs before release.
    private static final String BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";
    private static final String INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712";

    private LinearLayout root;
    private TextView questionText, scoreText;
    private Button[] answerButtons;
    private AdView bannerAd;
    private InterstitialAd interstitialAd;
    private int questionIndex = 0;
    private int score = 0;

    private final String[][] questions = {
        {"বাংলাদেশের রাজধানী কোনটি?", "ঢাকা", "চট্টগ্রাম", "সিলেট", "রাজশাহী", "ঢাকা"},
        {"জাতীয় ফুল কোনটি?", "গোলাপ", "শাপলা", "জবা", "বেলি", "শাপলা"},
        {"এক সপ্তাহে কয় দিন?", "পাঁচ", "ছয়", "সাত", "আট", "সাত"},
        {"সূর্য কোন দিকে ওঠে?", "পূর্ব", "পশ্চিম", "উত্তর", "দক্ষিণ", "পূর্ব"},
        {"বাংলাদেশের জাতীয় ফল কোনটি?", "আম", "কাঁঠাল", "লিচু", "কলা", "কাঁঠাল"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(12));
        root.setBackgroundColor(Color.rgb(246, 249, 255));

        TextView title = new TextView(this);
        title.setText("Quiz শিক্ষা");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(25, 75, 145));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(18));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        scoreText = new TextView(this);
        scoreText.setText("স্কোর: 0");
        scoreText.setTextSize(18);
        scoreText.setTextColor(Color.DKGRAY);
        scoreText.setGravity(Gravity.CENTER);
        root.addView(scoreText, new LinearLayout.LayoutParams(-1, -2));

        questionText = new TextView(this);
        questionText.setTextSize(22);
        questionText.setTextColor(Color.BLACK);
        questionText.setGravity(Gravity.CENTER);
        questionText.setPadding(dp(4), dp(28), dp(4), dp(22));
        root.addView(questionText, new LinearLayout.LayoutParams(-1, -2));

        answerButtons = new Button[4];
        for (int i = 0; i < 4; i++) {
            final int optionIndex = i;
            Button button = new Button(this);
            button.setAllCaps(false);
            button.setTextSize(17);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(5), 0, dp(5));
            root.addView(button, lp);
            answerButtons[i] = button;
            button.setOnClickListener(v -> checkAnswer(optionIndex));
        }

        View spacer = new View(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));

        bannerAd = new AdView(this);
        bannerAd.setAdSize(AdSize.BANNER);
        bannerAd.setAdUnitId(BANNER_AD_UNIT_ID);
        root.addView(bannerAd, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);

        MobileAds.initialize(this, initializationStatus -> {
            bannerAd.loadAd(new AdRequest.Builder().build());
            loadInterstitial();
        });
        showQuestion();
    }

    private void showQuestion() {
        if (questionIndex >= questions.length) {
            questionText.setText("কুইজ শেষ! তোমার স্কোর: " + score + "/" + questions.length);
            for (Button b : answerButtons) b.setVisibility(View.GONE);
            Button restart = new Button(this);
            restart.setText("আবার খেলুন");
            restart.setAllCaps(false);
            root.addView(restart, root.indexOfChild(bannerAd), new LinearLayout.LayoutParams(-1, -2));
            restart.setOnClickListener(v -> {
                score = 0;
                questionIndex = 0;
                scoreText.setText("স্কোর: 0");
                for (Button b : answerButtons) b.setVisibility(View.VISIBLE);
                root.removeView(restart);
                showQuestion();
            });
            if (interstitialAd != null) {
                interstitialAd.show(this);
                interstitialAd = null;
                loadInterstitial();
            }
            return;
        }
        String[] q = questions[questionIndex];
        questionText.setText((questionIndex + 1) + ". " + q[0]);
        for (int i = 0; i < 4; i++) answerButtons[i].setText(q[i + 1]);
    }

    private void checkAnswer(int selected) {
        String chosen = answerButtons[selected].getText().toString();
        String correct = questions[questionIndex][5];
        if (chosen.equals(correct)) {
            score++;
            Toast.makeText(this, "সঠিক উত্তর!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "সঠিক উত্তর: " + correct, Toast.LENGTH_SHORT).show();
        }
        scoreText.setText("স্কোর: " + score);
        questionIndex++;
        showQuestion();
    }

    private void loadInterstitial() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, INTERSTITIAL_AD_UNIT_ID, request,
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
                @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
            });
    }

    @Override protected void onDestroy() {
        if (bannerAd != null) bannerAd.destroy();
        super.onDestroy();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
